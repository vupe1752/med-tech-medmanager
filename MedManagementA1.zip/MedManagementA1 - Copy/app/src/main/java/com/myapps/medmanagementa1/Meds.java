package com.myapps.medmanagementa1;

import java.util.Comparator;

public class Meds {
    private String naMe;
    private String doSe;
    private String instructions;
    private String providEr;

    public Meds(String naMe, String doSe, String instructions, String providEr) {
        this.naMe = naMe;
        this.doSe = doSe;
        this.instructions = instructions;
        this.providEr = providEr;
    }

    public String getNaMe() {
        return naMe;
    }

    public void setNaMe(String naMe) {
        this.naMe = naMe;
    }

    public String getDoSe() {
        return doSe;
    }

    public void setDoSe(String doSe) {
        this.doSe = doSe;
    }

    public String getInstructions() {
        return instructions;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }

    public String getProvidEr() {
        return providEr;
    }

    public void setProvidEr(String providEr) {
        this.providEr = providEr;
    }
}