package com.myapps.medmanagementa1;


import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AReminderListAdapter extends ArrayAdapter<AReminder> {
    private Context mContext;
    int mResource;
    ArrayList <AReminder> AReminder_liSt1;
    WDbHelper wDbHelper;
    int inbtnState;
    int click_count = 0;

    Calendar c;

    public AReminderListAdapter(@NonNull Context context, int resource, @NonNull ArrayList<AReminder> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
        AReminder_liSt1 = objects;
        wDbHelper = new WDbHelper(mContext);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //get the person info
        final String timeSet = getItem(position).getTimeSet();
        final String btn_staTe = getItem(position).getBtnState();
        final String recur_daTe = getItem(position).getRecurDate();

        //create the person object with the injo
        final AReminder AReminder = new AReminder(timeSet, btn_staTe, recur_daTe);

        LayoutInflater inflater = LayoutInflater.from(mContext);
        convertView = inflater.inflate(mResource, parent, false);

        Button reminderTimer = (Button) convertView.findViewById(R.id.reminder_time);
        Button btnDelete = (Button) convertView.findViewById(R.id.btn_delete);
        final Button btnControl = (Button) convertView.findViewById(R.id.control_reminder);
        Button recurrentDate = (Button) convertView.findViewById(R.id.repeating_date);

        reminderTimer.setText(timeSet);
        SpannableString spannable = new SpannableString(recur_daTe);
        Cursor dataExactReminder = wDbHelper.getExactReminder(AAddMedication.med_naMe1,timeSet);
        while (dataExactReminder.moveToNext()) {
            String re_daTe = dataExactReminder.getString( 6);
        // here we set the color
        if ((Integer.parseInt(re_daTe)) == 8) {
            String date = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
             recurrentDate.setText(date);
        }
        else {
        if ((Integer.parseInt(re_daTe)) == 7) {
            spannable.setSpan(new ForegroundColorSpan(mContext.getResources().getColor(R.color.colorPrimary)),
                    0, 1, 0);
        }
        if ((Integer.parseInt(re_daTe)) == 1) {
            spannable.setSpan(new ForegroundColorSpan(mContext.getResources().getColor(R.color.colorPrimary)),
                    2, 3, 0);
        }
        if ((Integer.parseInt(re_daTe)) == 2) {
            spannable.setSpan(new ForegroundColorSpan(mContext.getResources().getColor(R.color.colorPrimary)),
                    4, 5, 0);
        }
        if ((Integer.parseInt(re_daTe)) == 3) {
            spannable.setSpan(new ForegroundColorSpan(mContext.getResources().getColor(R.color.colorPrimary)),
                    6, 7, 0);
        }
        if ((Integer.parseInt(re_daTe)) == 4) {
            spannable.setSpan(new ForegroundColorSpan(mContext.getResources().getColor(R.color.colorPrimary)),
                    8, 9, 0);
        }
        if ((Integer.parseInt(re_daTe)) == 5) {
            spannable.setSpan(new ForegroundColorSpan(mContext.getResources().getColor(R.color.colorPrimary)),
                    10, 11, 0);
        }
        if ((Integer.parseInt(re_daTe)) == 6) {
            spannable.setSpan(new ForegroundColorSpan(mContext.getResources().getColor(R.color.colorPrimary)),
                    12, 13, 0);
        }
        recurrentDate.setText(spannable);
        }}

        //Set the color of the alarm buttons
        inbtnState = Integer.parseInt(btn_staTe);
        if(inbtnState % 2 == 0){
            btnControl.setBackgroundColor(mContext.getResources().getColor(R.color.colorAccent));

        }
        else {
            btnControl.setBackgroundColor(mContext.getResources().getColor(R.color.colorPrimary));
        }

        //TO delete the reminder
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Context context = mContext.getApplicationContext();
                AlarmManager alarmManager = (AlarmManager)context.getSystemService(context.ALARM_SERVICE);
                Intent intent = new Intent(context, WAlertReceiver.class );
                Cursor dataExactReminder = wDbHelper.getExactReminder(AAddMedication.med_naMe1,timeSet);
                while (dataExactReminder.moveToNext()) {
                    String request_codeId = dataExactReminder.getString( 0);
                PendingIntent pendingIntent = PendingIntent.getActivity(context, Integer.parseInt(request_codeId),
                        intent, PendingIntent.FLAG_UPDATE_CURRENT);
                alarmManager.cancel(pendingIntent);}
                AReminder_liSt1.remove(position);
                wDbHelper.deleteReminder(AAddMedication.med_naMe1,timeSet);
                notifyDataSetChanged();
            }
        });

        //Edit AReminder
        reminderTimer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AReminder_liSt1.remove(position);
                wDbHelper.deleteReminder(AAddMedication.med_naMe1,timeSet);
                Intent intent = new Intent(mContext, ASetReminder.class);
                mContext.startActivity(intent);
            }
        });

        btnControl.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View view) {
                click_count ++;
                int btncount_saVe = inbtnState + click_count;
                wDbHelper.updateReminder(AAddMedication.med_naMe1, timeSet,
                        String.valueOf(btncount_saVe));

                //To turn the reminder on/off
                SimpleDateFormat dateFormat2 = new SimpleDateFormat("hh:mm aa");
                try {Date ca= (Date) dateFormat2.parse(timeSet);
                    c = Calendar.getInstance();
                    c.setTime(ca); }
                catch (ParseException e) {
                    e.printStackTrace();}

                Context context = mContext.getApplicationContext();
                AlarmManager alarmManager = (AlarmManager)context.getSystemService(context.ALARM_SERVICE);
                Intent intent = new Intent(context, WAlertReceiver.class );

                if(btncount_saVe % 2 == 0){
                    btnControl.setBackgroundColor(mContext.getResources().getColor(R.color.colorAccent));
                    Cursor dataExactReminder = wDbHelper.getExactReminder(AAddMedication.med_naMe1,timeSet);
                    while (dataExactReminder.moveToNext()) {
                        String request_codeId = dataExactReminder.getString( 0);
                    PendingIntent pendingIntent = PendingIntent.getActivity(context, Integer.parseInt(request_codeId),
                            intent, PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pendingIntent);}
                }
                else{
                    btnControl.setBackgroundColor(mContext.getResources().getColor(R.color.colorPrimary));
                    Cursor dataExactReminder = wDbHelper.getExactReminder(AAddMedication.med_naMe1,timeSet);
                    while (dataExactReminder.moveToNext()) {
                        String request_codeId = dataExactReminder.getString( 0);
                    PendingIntent pendingIntent = PendingIntent.getActivity(context, Integer.parseInt(request_codeId),
                            intent, PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);}
                   }
            }
        });

        return convertView;
    }

}


