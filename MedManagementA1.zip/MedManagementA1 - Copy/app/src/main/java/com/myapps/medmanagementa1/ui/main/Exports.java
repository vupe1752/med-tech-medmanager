package com.myapps.medmanagementa1.ui.main;


import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;

import com.myapps.medmanagementa1.R;
import com.myapps.medmanagementa1.WDbHelper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;


public class Exports extends Fragment {

    Button exportActive, startDate, endDate, exportDate;
    WDbHelper wDbHelper;
    CVSWriter cvsWriter;

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.export_layout, container, false);
        return root;
    }
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        exportActive = view.findViewById(R.id.export_active);
        startDate = view.findViewById(R.id.exstart_date);
        endDate = view.findViewById(R.id.exend_date);
        wDbHelper = new WDbHelper(getContext());
        final Cursor dataExport5 = wDbHelper.getActiveMedicationList();
        exportActive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 StringBuilder data5 = new StringBuilder();
                data5.append("Active, Medications, Dose, Instruction, Provider");
                while (dataExport5.moveToNext()) {
                    data5.append("\n" + dataExport5.getString(1) + "," + dataExport5.getString(2) +
                            "," + dataExport5.getString(3) + "'" + dataExport5.getString(7));}

                try {
                    //Save file into device
                    FileOutputStream out = openFileOutput("class_attendance.csv", MODE_PRIVATE);
                    out.write((data5.toString()).getBytes());
                    out.close();

                    //Exporting
                    Context context = getApplicationContext();
                    File newFile = new File(getFilesDir(), "class_attendance.csv");

                    Uri path = FileProvider.getUriForFile(context, "com.mydomain.attendancetakerappprovider",
                            newFile);
                    Intent fileIntent = new Intent(Intent.ACTION_SEND);
                    fileIntent.setType("text/csv");
                    fileIntent.putExtra(Intent.EXTRA_SUBJECT, MainActivity.spinner_claSs + " " + ViewSelection.selected_daTe6);
                    fileIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    fileIntent.putExtra(Intent.EXTRA_STREAM, path);
                    startActivity(Intent.createChooser(fileIntent, "Send mail"));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
