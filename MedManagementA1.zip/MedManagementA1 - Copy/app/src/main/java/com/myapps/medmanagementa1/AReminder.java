package com.myapps.medmanagementa1;

public class AReminder {
    private String timeSet;
    private String btnState;
    private String recurDate;

    private int hashCode;

    public AReminder(String timeSet, String btnState, String recurDate) {
        this.timeSet = timeSet;
        this.btnState = btnState;
        this.recurDate = recurDate;
    }

    public String getTimeSet() {
        return timeSet;
    }

    public void setTimeSet(String timeSet) {
        this.timeSet = timeSet;
    }

    public String getBtnState() {
        return btnState;
    }

    public void setBtnState(String btnState) {
        this.btnState = btnState;
    }

    public String getRecurDate() {
        return recurDate;
    }

    public void setRecurDate(String recurDate) {
        this.recurDate = recurDate;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof AReminder) {
        AReminder aReminder = (AReminder) obj;
        if(timeSet.equals(aReminder.timeSet) &&
                btnState.equals(aReminder.btnState) &&
                recurDate.equals(aReminder.recurDate))
        return true;}
        return false;}

    @Override
    public int hashCode() {
        // TODO Auto-generated method stub
        return (this.timeSet.hashCode() + this.btnState.hashCode() + this.recurDate.hashCode());
    }


}
