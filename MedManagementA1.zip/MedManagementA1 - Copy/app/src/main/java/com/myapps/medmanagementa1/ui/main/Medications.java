package com.myapps.medmanagementa1.ui.main;


import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.myapps.medmanagementa1.AAddMedication;
import com.myapps.medmanagementa1.MedArchivedListAdapter;
import com.myapps.medmanagementa1.MedListAdapter;
import com.myapps.medmanagementa1.Meds;
import com.myapps.medmanagementa1.R;
import com.myapps.medmanagementa1.WDbHelper;

import java.util.ArrayList;

public class Medications extends Fragment{

    Button btnAdd;
    ListView medList, archivedMedList;
    WDbHelper WDbHelper;
    public static ArrayList<Meds> med_liSt, archived_mEd;
    public static MedArchivedListAdapter adapterb;
    public static MedListAdapter adaptera;
    static String mEd;

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.med_tracker_tablayout, container, false);
        return root;
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        btnAdd = view.findViewById(R.id.btn_add);
        medList = view.findViewById(R.id.active_med_list);
        archivedMedList = view.findViewById(R.id.archived_med_list);

        WDbHelper = new WDbHelper(getActivity());

        med_liSt = new ArrayList<>();
        Meds medsa = new Meds ("Ibuprofen", "200mg", "as needed", "OTC");
        med_liSt.add(medsa);
        MedListAdapter adaptera = new MedListAdapter(getContext(),
                R.layout.medlist_adapter_layout, med_liSt);
        medList.setAdapter(adaptera);
        Cursor data = WDbHelper.getActiveMedicationList();
        while (data.moveToNext()) {
            med_liSt.add(new Meds (data.getString(1), data.getString(2), data.getString(3),
                    data.getString(7)));
            adaptera.notifyDataSetChanged();
        }

        archived_mEd = new ArrayList<>();
        Meds medsb = new Meds ("Tylenol", null, null, null);
        archived_mEd.add(medsb);
        MedArchivedListAdapter adapterb = new MedArchivedListAdapter(getContext(),
                R.layout.archivedmed_adapter, archived_mEd);
        archivedMedList.setAdapter(adapterb);
        Cursor datab = WDbHelper.getArchivedMedicationList();
        while (datab.moveToNext()) {
            archived_mEd.add(new Meds (datab.getString(1), "", "",
                    ""));
            adapterb.notifyDataSetChanged();
        }

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), AAddMedication.class);
                startActivity(intent);
            }
        });

    }
}
