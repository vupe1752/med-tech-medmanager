package com.myapps.medmanagementa1;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import com.myapps.medmanagementa1.ui.main.Medications;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import static com.myapps.medmanagementa1.ui.main.Medications.adapterb;
import static com.myapps.medmanagementa1.ui.main.Medications.archived_mEd;

public class MedListAdapter extends ArrayAdapter<Meds> {
    private Context mContext3;
    int mResource3;
    ArrayList<Meds> med_liSt;
    WDbHelper WDbHelper;
    static String edit_mEd;
    int count = 0;

    public MedListAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Meds> objects) {
        super(context, resource, objects);
        mContext3 = context;
        mResource3 = resource;
        med_liSt = objects;
        WDbHelper = new WDbHelper(mContext3);

    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //get the person info
        final String naMe3 = getItem(position).getNaMe();
        final String doSe3 = getItem(position).getDoSe();
        final String instructiOn3 = getItem(position).getInstructions();
        final String providEr3 = getItem(position).getProvidEr();

        //create the person object with the injo
        final Meds meds = new Meds(naMe3, doSe3, instructiOn3, providEr3);

        LayoutInflater inflater = LayoutInflater.from(mContext3);
        convertView = inflater.inflate(mResource3, parent, false);

        final Button medName3 = (Button) convertView.findViewById(R.id.med_name3);
        Button dose3 = (Button) convertView.findViewById(R.id.dose3);
        Button instruction3 = (Button) convertView.findViewById(R.id.instruction3);
        Button btnDelete3 = (Button) convertView.findViewById(R.id.btn_delete3);
        Button btnControl3a = (Button) convertView.findViewById(R.id.archive3);

        final Button medName3b = (Button) convertView.findViewById(R.id.med_name5);
        Button btnControl3b = (Button) convertView.findViewById(R.id.status_control5);

        medName3.setText(naMe3);
        dose3.setText(doSe3);
        instruction3.setText(instructiOn3);

        btnControl3a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                WDbHelper.updateStatus(naMe3, "archived");
                Toast.makeText(mContext3, naMe3, Toast.LENGTH_SHORT).show();

                med_liSt.remove(position);
                notifyDataSetChanged();

                Intent intent = new Intent (mContext3, MainActivity.class);
                mContext3.startActivity(intent);

        }});

        btnDelete3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder3b = new AlertDialog.Builder(mContext3);
                builder3b.setTitle("Delete confirmation")
                        .setMessage("Are you sure that you want to delete " + naMe3 + " ?")
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Context context = mContext3.getApplicationContext();
                                AlarmManager alarmManager = (AlarmManager)context.getSystemService(context.ALARM_SERVICE);
                                Intent intent = new Intent(context, WAlertReceiver.class );
                                Cursor dataReminder = WDbHelper.getReminders(naMe3);
                                while (dataReminder.moveToNext()) {
                                    String request_codeId = dataReminder.getString( 0);
                                    PendingIntent pendingIntent = PendingIntent.getActivity(context, Integer.parseInt(request_codeId),
                                            intent, PendingIntent.FLAG_UPDATE_CURRENT);
                                    alarmManager.cancel(pendingIntent);}

                                WDbHelper.deleteMed(naMe3);
                                med_liSt.remove(position);
                                notifyDataSetChanged();
                                Toast.makeText(mContext3, naMe3 + " was deleted.", Toast.LENGTH_LONG).show();
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });
                //Creating dialog box
                AlertDialog dialog  = builder3b.create();
                dialog.show();
            }
        });

        medName3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edit_mEd = medName3.getText().toString();
                Intent intent = new Intent (mContext3, AAddMedication.class);
                mContext3.startActivity(intent);
            }
        });

        return convertView;
    }
}


