package com.myapps.medmanagementa1;


import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static android.app.PendingIntent.FLAG_UPDATE_CURRENT;

public class ASetReminder extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    TextView testSpTime;
    Button btnMon, btnTue, btnWed, btnThu, btnFri, btnSat, btnSun, btnCancel2, btnSave2;
    TimePicker timePicker2;
    int count2, countM = 1, countT = 1, countW = 1, countTh = 1, countF = 1, countS = 1, countSu = 1;
    WDbHelper wDbHelper;
    static String time_sEt2;
    Calendar c2;
    Spinner spinnerAlarm2;
    String selected_tiMe2, selected_daTe2;
    String doWM, doWT, doWW, doWTh, doWF, doWS, doWSu, int_tiMe;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.set_alarm_layout);

        btnSave2 = findViewById(R.id.save2);
        btnCancel2 = findViewById(R.id.cancel2);
        spinnerAlarm2 = findViewById(R.id.spinner_alarm2);
        testSpTime = findViewById(R.id.test_spinnertime);
        testSpTime.setVisibility(View.INVISIBLE);
        btnMon = findViewById(R.id.mon);
        btnTue = findViewById(R.id.tue);
        btnWed = findViewById(R.id.wed);
        btnThu = findViewById(R.id.thu);
        btnFri = findViewById(R.id.fri);
        btnSat = findViewById(R.id.sat);
        btnSun = findViewById(R.id.sun);

        wDbHelper = new WDbHelper(this);

        timePicker2 = findViewById(R.id.time_picker2);

        //Select a set reminder
        List <String> all_remindeRs = new ArrayList<>();
        all_remindeRs.add("");
        ArrayAdapter <String> adapter2 = new ArrayAdapter<>(ASetReminder.this, android.R.layout.simple_spinner_dropdown_item,
                all_remindeRs);
        spinnerAlarm2.setAdapter(adapter2);
        final Cursor dataAllReminders = wDbHelper.getAllReminders();
        while (dataAllReminders.moveToNext()) {
            all_remindeRs.add(dataAllReminders.getString(2));

            Set<String> trial = new HashSet<String>();
            trial.addAll(all_remindeRs);
            all_remindeRs.clear();
            all_remindeRs.addAll(trial);

            adapter2.notifyDataSetChanged();}

        // Select a reminder time from spinner alarm
        spinnerAlarm2.setOnItemSelectedListener(this);

        doWM = "0"; doWT = "0"; doWW = "0"; doWTh = "0"; doWF = "0"; doWS = "0"; doWSu = "0";
        btnMon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                countM = countM + 1;
                if (countM % 2 == 0) {
                    doWM = String.valueOf(1); }
                else {doWM = String.valueOf(0);}
                Toast.makeText(ASetReminder.this, String.valueOf(countM), Toast.LENGTH_SHORT).show();
            }
        });
        btnTue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                countT = countT + 1;
                if (countT % 2 == 0) {
                doWT = String.valueOf(2); }
                else {doWT = String.valueOf(0);}
                Toast.makeText(ASetReminder.this, String.valueOf(countT), Toast.LENGTH_SHORT).show();
            }
        });
        btnWed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                countW = countW + 1;
                if (countW % 2 == 0) {
                    doWW = String.valueOf(3); }
                else {doWW = String.valueOf(0);}
                Toast.makeText(ASetReminder.this, String.valueOf(countW), Toast.LENGTH_SHORT).show();
            }
        });
        btnThu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                countTh = countTh + 1;
                if (countTh % 2 == 0) {
                    doWTh = String.valueOf(4); }
                else {doWTh = String.valueOf(0);}
                Toast.makeText(ASetReminder.this, String.valueOf(countTh), Toast.LENGTH_SHORT).show();
            }
        });
        btnFri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                countF = countF + 1;
                if (countF % 2 == 0) {
                    doWF = String.valueOf(5); }
                else {doWF = String.valueOf(0);}
                Toast.makeText(ASetReminder.this, String.valueOf(countF), Toast.LENGTH_SHORT).show();
            }
        });
        btnSat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                countS = countS + 1;
                if (countS % 2 == 0) {
                    doWS = String.valueOf(6); }
                else {doWS = String.valueOf(0);}
                Toast.makeText(ASetReminder.this, String.valueOf(countS), Toast.LENGTH_SHORT).show();
            }
        });
        btnSun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                countSu = countSu + 1;
                if (countSu % 2 == 0) {
                    doWSu = String.valueOf(7); }
                else {doWSu = String.valueOf(0);}
                Toast.makeText(ASetReminder.this, String.valueOf(countSu), Toast.LENGTH_SHORT).show();
            }
        });

        // Set a time using timepicker
        btnSave2.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View view) {
                if (testSpTime.length() != 0) {
                    SimpleDateFormat dateFormat2 = new SimpleDateFormat("hh:mm aa");
                    try {
                        Date c2a= (Date) dateFormat2.parse(selected_tiMe2);
                        Calendar c2t = Calendar.getInstance();
                        c2t.setTime(c2a);
                        int shours = c2t.get(Calendar.HOUR_OF_DAY);
                        int sminutes = c2t.get(Calendar.MINUTE);
                        c2 = Calendar.getInstance();
                        c2.set(Calendar.HOUR_OF_DAY,shours);
                        c2.set(Calendar.MINUTE, sminutes);
                        c2.set(Calendar.SECOND, 0);

                        int stimeinminutes = shours * 60 + sminutes;
                        int_tiMe = String.valueOf(stimeinminutes);

                        // Insert reminder details to DB
                        time_sEt2 = DateFormat.getTimeInstance(DateFormat.SHORT).format(c2.getTime());
                        if ((Integer.parseInt(doWM)) == 1||(Integer.parseInt(doWT)) == 2||(Integer.parseInt(doWW)) == 3||(Integer.parseInt(doWTh)) == 4||
                                (Integer.parseInt(doWF)) == 5||(Integer.parseInt(doWS)) == 6||(Integer.parseInt(doWSu)) == 7) {
                            // Save data (must be here before the set AlarmManager)
                            if ((Integer.parseInt(doWM)) == 1) {
                                wDbHelper.insertMedReminder(AAddMedication.med_naMe1, time_sEt2, int_tiMe, "0", doWM, selected_daTe2);}
                            if ((Integer.parseInt(doWT)) == 2) {
                                wDbHelper.insertMedReminder(AAddMedication.med_naMe1, time_sEt2, int_tiMe, "0", doWT, selected_daTe2);}
                            if ((Integer.parseInt(doWW)) == 3) {
                                wDbHelper.insertMedReminder(AAddMedication.med_naMe1, time_sEt2, int_tiMe, "0", doWW, selected_daTe2);}
                            if ((Integer.parseInt(doWTh)) == 4) {
                                wDbHelper.insertMedReminder(AAddMedication.med_naMe1, time_sEt2, int_tiMe, "0", doWTh, selected_daTe2);}
                            if ((Integer.parseInt(doWF)) == 5) {
                                wDbHelper.insertMedReminder(AAddMedication.med_naMe1, time_sEt2, int_tiMe, "0", doWF, selected_daTe2);}
                            if ((Integer.parseInt(doWS)) == 6) {
                                wDbHelper.insertMedReminder(AAddMedication.med_naMe1, time_sEt2, int_tiMe, "0", doWS, selected_daTe2);}
                            if ((Integer.parseInt(doWSu)) == 7) {
                                wDbHelper.insertMedReminder(AAddMedication.med_naMe1, time_sEt2, int_tiMe, "0", doWSu, selected_daTe2);}
                            //Set AlarmManager
                            Cursor dataReminder = wDbHelper.getExactReminder(AAddMedication.med_naMe1, time_sEt2);
                            while (dataReminder.moveToNext()) {
                                String count2s = dataReminder.getString(0);
                                String re_daTes = dataReminder.getString(6);
                                count2 = Integer.parseInt(count2s);
                                int re_daTe = Integer.parseInt(re_daTes);
                                c2.add(Calendar.DATE, re_daTe);

                                Context context = getApplicationContext();
                                AlarmManager alarmManager = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
                                Intent intent2 = new Intent(context, WAlertReceiver.class);
                                PendingIntent pendingIntent = PendingIntent.getActivity(context, count2, intent2, FLAG_UPDATE_CURRENT);
                                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY*7, pendingIntent);

                                Toast.makeText(context, String.valueOf(count2), Toast.LENGTH_SHORT).show();}}
                        else {wDbHelper.insertMedReminder(AAddMedication.med_naMe1, time_sEt2, int_tiMe, "0", "8", selected_daTe2);
                            //Set AlarmManager
                            Cursor dataReminder = wDbHelper.getExactReminder(AAddMedication.med_naMe1, time_sEt2);
                            while (dataReminder.moveToNext()) {
                                String count2s = dataReminder.getString(0);
                                count2 = Integer.parseInt(count2s);

                                Context context = getApplicationContext();
                                AlarmManager alarmManager = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
                                Intent intent2 = new Intent(context, WAlertReceiver.class);
                                PendingIntent pendingIntent = PendingIntent.getActivity(context, count2, intent2, FLAG_UPDATE_CURRENT);
                                alarmManager.setExact(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), pendingIntent);

                                Toast.makeText(context, String.valueOf(count2), Toast.LENGTH_SHORT).show();}}

                        }

                    catch (ParseException e) { e.printStackTrace();} }
                else {
                    //Pick a time
                    int hours = timePicker2.getCurrentHour();
                    int mins = timePicker2.getCurrentMinute();
                    c2 = Calendar.getInstance();
                    c2.set(Calendar.HOUR_OF_DAY, hours);
                    c2.set(Calendar.MINUTE, mins);
                    c2.set(Calendar.SECOND, 0);
                    int timeinminutes = hours * 60 + mins;
                    int_tiMe = String.valueOf(timeinminutes);

                    // Insert reminder details to DB
                    time_sEt2 = DateFormat.getTimeInstance(DateFormat.SHORT).format(c2.getTime());
                    if ((Integer.parseInt(doWM)) == 1||(Integer.parseInt(doWT)) == 2||(Integer.parseInt(doWW)) == 3||(Integer.parseInt(doWTh)) == 4||
                            (Integer.parseInt(doWF)) == 5||(Integer.parseInt(doWS)) == 6||(Integer.parseInt(doWSu)) == 7) {
                        // Save data (must be here before the set AlarmManager)
                        if ((Integer.parseInt(doWM)) == 1) {
                            wDbHelper.insertMedReminder(AAddMedication.med_naMe1, time_sEt2, int_tiMe, "0", doWM, null);}
                        if ((Integer.parseInt(doWT)) == 2) {
                            wDbHelper.insertMedReminder(AAddMedication.med_naMe1, time_sEt2, int_tiMe, "0", doWT, null);}
                        if ((Integer.parseInt(doWW)) == 3) {
                            wDbHelper.insertMedReminder(AAddMedication.med_naMe1, time_sEt2, int_tiMe, "0", doWW, null);}
                        if ((Integer.parseInt(doWTh)) == 4) {
                            wDbHelper.insertMedReminder(AAddMedication.med_naMe1, time_sEt2, int_tiMe, "0", doWTh, null);}
                        if ((Integer.parseInt(doWF)) == 5) {
                            wDbHelper.insertMedReminder(AAddMedication.med_naMe1, time_sEt2, int_tiMe, "0", doWF, null);}
                        if ((Integer.parseInt(doWS)) == 6) {
                            wDbHelper.insertMedReminder(AAddMedication.med_naMe1, time_sEt2, int_tiMe, "0", doWS, null);}
                        if ((Integer.parseInt(doWSu)) == 7) {
                            wDbHelper.insertMedReminder(AAddMedication.med_naMe1, time_sEt2, int_tiMe, "0", doWSu, null);}}
                    else {wDbHelper.insertMedReminder(AAddMedication.med_naMe1, time_sEt2, int_tiMe, "0", "8", null);}

                        //Set AlarmManager
                        Cursor dataReminder = wDbHelper.getExactReminder(AAddMedication.med_naMe1, time_sEt2);
                        while (dataReminder.moveToNext()) {
                            String count2s = dataReminder.getString(0);
                            count2 = Integer.parseInt(count2s);

                            Context context = getApplicationContext();
                            AlarmManager alarmManager = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
                            Intent intent2 = new Intent(context, WAlertReceiver.class);
                            PendingIntent pendingIntent = PendingIntent.getActivity(context, count2, intent2, FLAG_UPDATE_CURRENT);
                            alarmManager.setExact(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), pendingIntent);

                            Toast.makeText(context, String.valueOf(count2), Toast.LENGTH_SHORT).show();}}

                //Go back to Main Activity
                Intent intent2a = new Intent (ASetReminder.this, AAddMedication.class);
                startActivity(intent2a);
            }
        });

        btnCancel2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2b = new Intent (ASetReminder.this, AAddMedication.class);
                startActivity(intent2b);
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
        selected_tiMe2 = adapterView.getItemAtPosition(position).toString();
        testSpTime.setText(selected_tiMe2);
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
    }

}


