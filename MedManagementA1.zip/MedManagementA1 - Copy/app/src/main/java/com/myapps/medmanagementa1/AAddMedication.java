package com.myapps.medmanagementa1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.myapps.medmanagementa1.ui.main.Medications;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class AAddMedication extends AppCompatActivity implements MedDialog.MedDialogListener, SelectDateDialog.SelectDateDialogListener,
    SelectDateDialogB.SelectDateDialogBListener {

    Button setReminder1, btnSave1, btnCancel1, btnMed1, startDate1, endDate1;
    EditText dose1, instruction1, note1, providerName1, startDateText1, endDateText1;
    TextView testText;
    static String med_naMe1;
    WDbHelper WDbHelper;
    ListView listView1;
    String testiNg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_medication_layout);

        setReminder1 = findViewById(R.id.set_reminder1);
        btnSave1 = findViewById(R.id.save1);
        btnCancel1 = findViewById(R.id.cancel1);
        btnMed1 = findViewById(R.id.med_name1);
        dose1 = findViewById(R.id.dose1);
        note1 = findViewById(R.id.note1);
        instruction1 = findViewById(R.id.instruction1);
        listView1 = findViewById(R.id.listView1);
        testText = findViewById(R.id.testing);
        testText.setVisibility(View.INVISIBLE);
        startDate1 = findViewById(R.id.btnstart_date1);
        endDate1 = findViewById(R.id.btnend_date1);
        startDateText1 = findViewById(R.id.start_date1);
        endDateText1 = findViewById(R.id.end_date1);

        providerName1 = findViewById(R.id.provider_name1);

        WDbHelper = new WDbHelper(this);

        //Enter new medication name
        btnMed1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog();
            }
        });

        //Display in progress med details
        Cursor dataMedDetails = WDbHelper.getMedicationDetails(med_naMe1);
        while (dataMedDetails .moveToNext()) {
            btnMed1.setText(dataMedDetails .getString(1));
            dose1.setText (dataMedDetails .getString(2));
            instruction1.setText(dataMedDetails .getString(3));
            note1.setText(dataMedDetails.getString(4));
            startDateText1.setText(dataMedDetails.getString(5));
            endDateText1.setText(dataMedDetails.getString(6));
            providerName1.setText(dataMedDetails.getString(7));}

        //View after return from ASetReminder
        ArrayList <AReminder> AReminder_liSt1 = new ArrayList<>();
        AReminderListAdapter adapter = new AReminderListAdapter(this,
                R.layout.reminder_adapter_layout, AReminder_liSt1);
        listView1.setAdapter(adapter);
        Cursor dataReminders = WDbHelper.getReminders(med_naMe1);
        while (dataReminders.moveToNext()) {
            testiNg = dataReminders.getString(2);
            testText.setText(testiNg);
            String btn_staTe = dataReminders.getString( 4);
            if (testText.length() !=  0) {
                AReminder_liSt1.add(new AReminder(testiNg, btn_staTe, "S M T W T F S"));

                Set<AReminder> trial = new HashSet<AReminder>();
                trial.addAll(AReminder_liSt1);
                AReminder_liSt1.clear();
                AReminder_liSt1.addAll(trial);

                adapter.notifyDataSetChanged();}}

        startDate1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialogDate();
            }
        });

        endDate1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialogDateB();
            }
        });

        //Set AReminder
        setReminder1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                WDbHelper.updateMed(med_naMe1, dose1.getText().toString(),instruction1.getText().toString(),
                        note1.getText().toString(), providerName1.getText().toString());
                Intent intent1 = new Intent (AAddMedication.this, ASetReminder.class);
                startActivity(intent1);
            }
        });

        btnCancel1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                WDbHelper.deleteMed(med_naMe1);
                Intent intent1a = new Intent (AAddMedication.this, MainActivity.class);
                startActivity(intent1a);
            }
        });

        btnSave1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                WDbHelper.updateMed(med_naMe1,
                        dose1.getText().toString(),instruction1.getText().toString(), note1.getText().toString(),
                        providerName1.getText().toString());
                WDbHelper.updateStart(med_naMe1, startDateText1.getText().toString());
                WDbHelper.updateEnd(med_naMe1, endDateText1.getText().toString());
                btnMed1.setText("");
                med_naMe1 = null;
                Intent intent1b = new Intent (AAddMedication.this, MainActivity.class);
                startActivity(intent1b);
            }
        });
    }

    public void openDialog() {
        MedDialog medDialog = new MedDialog();
        medDialog.show(getSupportFragmentManager(), "Enter a name dialog");
    }

    @Override
    public void applyTextsMed(String med_dialOg) {
        med_naMe1 = med_dialOg;
        btnMed1.setText(med_naMe1);
    }

    public void openDialogDate() {
        SelectDateDialog selectDateDialog = new SelectDateDialog();
        selectDateDialog.show(getSupportFragmentManager(), "Select a date dialog");
    }
    @Override
    public void applyTexts(String selectedDate) {
        startDateText1.setText(selectedDate);
        WDbHelper.updateStart(med_naMe1, selectedDate);
    }

    public void openDialogDateB() {
        SelectDateDialogB selectDateDialogB = new SelectDateDialogB();
        selectDateDialogB.show(getSupportFragmentManager(), "Select a date dialog");
    }
    @Override
    public void applyTextsB(String selectedDateB) {
        endDateText1.setText(selectedDateB);
        WDbHelper.updateEnd(med_naMe1, selectedDateB);
    }
}



