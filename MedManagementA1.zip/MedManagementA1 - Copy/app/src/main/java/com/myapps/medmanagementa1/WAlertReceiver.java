package com.myapps.medmanagementa1;


import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static android.app.PendingIntent.FLAG_UPDATE_CURRENT;

public class WAlertReceiver extends AppCompatActivity {

    static Ringtone r;
    WDbHelper wDbHelper;
    ListView firedAlarm;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.stop_alarm_layout);

        Button btnStop = (Button) findViewById(R.id.btn_stop);
        Button btnSnooze = (Button) findViewById(R.id.btn_snooze);
        firedAlarm = findViewById(R.id.fired_alarm);

        final Calendar c = Calendar.getInstance();
        int hours = c.get(Calendar.HOUR_OF_DAY);
        int mins = c.get(Calendar.MINUTE);
        int timeinmin = hours * 60 + mins;

        final Calendar c_snooze = Calendar.getInstance();
        c_snooze.add(Calendar.MINUTE, 10);

        int l = timeinmin - 15;
        int h = timeinmin + 15;

        Toast.makeText(this, String.valueOf(timeinmin), Toast.LENGTH_SHORT).show();

        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        r = RingtoneManager.getRingtone(this, notification);
        r.play();

        //Display all fired Reminders w/i 15 minutes
        List <String> fired_remindeRs = new ArrayList<>();
        fired_remindeRs.add("Medications need to take within +/- 15 mins");
        ArrayAdapter <String> adapter = new ArrayAdapter <> (this, android.R.layout.simple_list_item_1,
                fired_remindeRs);
        firedAlarm.setAdapter(adapter);
        wDbHelper = new WDbHelper(this);
        Cursor dataSpeReminder = wDbHelper.getSpecificReminder(l,h);
        while (dataSpeReminder.moveToNext()) {
            fired_remindeRs.add(dataSpeReminder.getString(1));

            Set<String> trial = new HashSet<String>();
            trial.addAll(fired_remindeRs);
            fired_remindeRs.clear();
            fired_remindeRs.addAll(trial);

            adapter.notifyDataSetChanged();}

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                r.stop();
            }
        });

        final AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        final Intent intent = new Intent(getApplicationContext(), WAlertReceiver.class);
        btnSnooze.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                r.stop();
                //Set AlarmManager
                PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, intent, FLAG_UPDATE_CURRENT);
                if (c_snooze.before(Calendar.getInstance())) {
                    c_snooze.add(Calendar.DATE, 1);
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, c_snooze.getTimeInMillis(), pendingIntent); }
                Toast.makeText(getApplicationContext(), "Snoozed!",Toast.LENGTH_SHORT).show();
            }
        });
    }

}
